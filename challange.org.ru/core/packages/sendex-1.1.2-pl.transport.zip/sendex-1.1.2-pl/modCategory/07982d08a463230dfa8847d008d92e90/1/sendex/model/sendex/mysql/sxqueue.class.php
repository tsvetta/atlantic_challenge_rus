<?php
require_once (dirname(dirname(__FILE__)) . '/sxqueue.class.php');
class sxQueue_mysql extends sxQueue {}