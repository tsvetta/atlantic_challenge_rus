<?php
require_once (dirname(dirname(__FILE__)) . '/sxnewsletter.class.php');
class sxNewsletter_mysql extends sxNewsletter {}