<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'sxNewsletter',
    1 => 'sxSubscriber',
    2 => 'sxQueue',
  ),
);