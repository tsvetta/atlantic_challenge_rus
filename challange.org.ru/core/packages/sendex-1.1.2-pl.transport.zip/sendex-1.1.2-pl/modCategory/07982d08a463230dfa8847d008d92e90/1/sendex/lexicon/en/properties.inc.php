<?php

$_lang['sendex_prop_id'] = 'Id of newsletter.';
$_lang['sendex_prop_showInactive'] = 'Show inactive newsletters?';

$_lang['sendex_prop_tplSubscribeAuth'] = 'Chunk with subscribe form for authenticated users.';
$_lang['sendex_prop_tplSubscribeGuest'] = 'Chunk with subscribe form for anonymous users.';
$_lang['sendex_prop_tplUnsubscribe'] = 'Chunk with unsubscribe form.';
$_lang['sendex_prop_tplActivate'] = 'Chunk of email with link to activation of subscription.';
