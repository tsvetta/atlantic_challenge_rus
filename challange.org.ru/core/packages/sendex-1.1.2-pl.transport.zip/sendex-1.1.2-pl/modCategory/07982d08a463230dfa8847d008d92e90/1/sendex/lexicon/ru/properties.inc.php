<?php

$_lang['sendex_prop_id'] = 'Идентификатор рассылки.';
$_lang['sendex_prop_showInactive'] = 'Показывать неактивные рассылки?';

$_lang['sendex_prop_tplSubscribeAuth'] = 'Форма подписки на рассылку для авторизованных пользователей.';
$_lang['sendex_prop_tplSubscribeGuest'] = 'Форма подписки на рассылку для анонимов.';
$_lang['sendex_prop_tplUnsubscribe'] = 'Форма отписки от рассылки.';
$_lang['sendex_prop_tplActivate'] = 'Чанк с оформлением письма активации подписки.';