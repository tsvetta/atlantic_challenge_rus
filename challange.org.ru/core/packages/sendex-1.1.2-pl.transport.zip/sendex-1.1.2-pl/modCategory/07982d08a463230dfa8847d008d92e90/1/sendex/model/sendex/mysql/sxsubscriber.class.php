<?php
require_once (dirname(dirname(__FILE__)) . '/sxsubscriber.class.php');
class sxSubscriber_mysql extends sxSubscriber {}